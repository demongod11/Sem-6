1) The output of "k-means" will be written in a file named as "universe_clusters.txt" since the output is large enough for it not to completely fit in the stdout.

2) The output of "LGB" will be printed on the stdout itself.