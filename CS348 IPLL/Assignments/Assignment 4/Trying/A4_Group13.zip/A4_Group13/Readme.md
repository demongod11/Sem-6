1) Use make to compile and run.
2) Use make clean to clean the directory after execution. 
3) The reduce operations used during parsing and Success or Error Message in the end depending on parsing state are stored in output.txt file